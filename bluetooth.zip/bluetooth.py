#! /usr/bin/env python3
import serial
import time
import EV3BT
import cv2
import requests
import pymysql
from picamera import PiCamera
from datetime import datetime
from PIL import Image

#time = datetime.now()
#time+timedelta(days=5))
basename = "image"
check1 = True
check2 = True
weekend = ""
fcm = ""
try :
	EV3 = serial.Serial('/dev/rfcomm1')
	print("Listening for EV3 Bluetooth messages, press CTRL C to quit.")
	camera = PiCamera()
	while check1:
		n = EV3.inWaiting()
		if n != 0 & check1:
			s = EV3.read(n)
			userdata = {"param100" : weekend}
			resp = requests.get('http://scv0319.cafe24.com/man/checktest.php', params=userdata)
			print(resp.text)
			if resp.text == "false":
				continue
			check1 = False
			mail,value,s = EV3BT.decodeMessage(s, EV3BT.MessageType.Logic)
			print(mail, value)
			s = EV3BT.encodeMessage(EV3BT.MessageType.Logic, 'check1', True)
			print(EV3BT.printMessage(s))
			EV3.write(s)
			time.sleep(1)
		else:
			time.sleep(0.5)

	while check1 == False & check2:
		m = EV3.inWaiting()
		print('EV3 Moving...')
		if m != 0:
			check2 = False
			s1 = EV3.read(m)
			camera.start_preview()
			time.sleep(5)
			suffix = datetime.now().strftime("%y%m%d_%H%M%S")
			filename = "_".join([basename, suffix])
			camera.capture('/home/pi/PiCamera/' + filename + '.jpg')
			camera.stop_preview()
			img = cv2.imread('/home/pi/PiCamera/' + filename + '.jpg')
			
			#picture cut
			#image_crop('/home/pi/PiCamera/' + filename + '.jpg', '/home/pi/PiCamera/')
			#7sungboon data store
			#send php
			data = img[295,1266]
			print(data)
			userdata = {"param1" : data[0], "param2" : data[1], "param3" : data[2]}
			resp = requests.get('http://scv0319.cafe24.com/man/BIL.php', params=userdata)
			print(resp.text)

			data2 = img[301,1345]	
			print(data2)
			userdata2 = {"param4" : data2[0], "param5" : data2[1], "param6" : data2[2]}
			resp2 = requests.get('http://scv0319.cafe24.com/man/GLU.php', params=userdata2)
			print(resp2.text)

			data3 = img[292,1179]
			print(data3)
			userdata3 = {"param7" : data3[0], "param8" : data3[1], "param9" : data3[2]}
			resp3 = requests.get('http://scv0319.cafe24.com/man/KET.php', params=userdata3)
			print(resp3.text)
	
			data4 = img[287,509]
			print(data4)
			userdata4 = {"param10" : data4[0], "param11" : data4[1], "param12" : data4[2]}
			resp4 = requests.get('http://scv0319.cafe24.com/man/LEU.php', params=userdata4)
			print(resp4.text)

			data5 = img[286,877]
			print(data5)
			userdata5 = {"param13" : data5[0], "param14" : data5[1], "param15" : data5[2]}
			resp5 = requests.get('http://scv0319.cafe24.com/man/PHz.php', params=userdata5)
			print(resp5.text)

			data6 = img[286,758]
			print(data6)
			userdata6 = {"param16" : data6[0], "param17" : data6[1], "param18" : data6[2]}
			resp6 = requests.get('http://scv0319.cafe24.com/man/PRO.php', params=userdata6)
			print(resp6.text)

			data7 = img[306,1419]
			print(data7)
			userdata7 = {"param19" : data7[0], "param20" : data7[1], "param21" : data7[2]}
			resp7 = requests.get('http://scv0319.cafe24.com/man/URO.php', params=userdata7)
			print(resp7.text)
			check1 = True
			check2 = True
			
			
			userdata = {"param1000" : fcm}
			resp = requests.get('http://scv0319.cafe24.com/man/push_notification.php', params=userdata)
			print(resp.text)
			
		else :
			time.sleep(0.5)

except KeyboardInterrupt:
	pass
	
EV3.close()
	
